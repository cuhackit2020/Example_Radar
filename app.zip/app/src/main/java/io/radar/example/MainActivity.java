package io.radar.example;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import io.radar.sdk.Radar;
import io.radar.sdk.Radar.RadarCallback;
import io.radar.sdk.model.RadarEvent;
import io.radar.sdk.model.RadarGeofence;
import io.radar.sdk.model.RadarUser;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    public static String log = "";

    public static boolean autoTrack = false;

    private NotificationManager mNotificationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        //checkin text view
        TextView checkinTextView = (TextView) findViewById(R.id.checkinTextView);
        //log text view
        TextView logTextView = (TextView) findViewById(R.id.logTextView);

        //Icon image
        ImageView iconImageView = (ImageView) findViewById(R.id.iconImageView);

        String publishableKey = "prj_live_pk_6ac1db526bb82726907cd21fd87bc6bb7e5b6186"; // replace with your publishable API key
        Radar.initialize(publishableKey);

        //String userId = Utils.getUserId(this);
        //Radar.setUserId(userId);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] { Manifest.permission.ACCESS_FINE_LOCATION }, 0);
        }

        //TextView userIdTextView = findViewById(R.id.user_id_text_view);
        //userIdTextView.setText(userId);

        //edit checkin/checkout string
        Intent checkinIntent = getIntent();
        String s = checkinIntent.getStringExtra("key"); //if it's a string you stored.
        checkinTextView.setText(s);

        //edit the log (history)
        if (checkinIntent.getStringExtra("time") != null && checkinIntent.getStringExtra("str") != null) {
            log = checkinIntent.getStringExtra("time") + " " +
                    checkinIntent.getStringExtra("str") +
                    "\n" + log;
        }
        logTextView.setText(log);


        if (checkinIntent.getStringExtra("success") != null){
            //TURN ON DND When checked in
            if (checkinIntent.getStringExtra("success").equals("IN")) {
                changeInterruptionFiler(NotificationManager.INTERRUPTION_FILTER_NONE);
                //change image to checkMark
                int imageResource = getResources().getIdentifier("@drawable/green_check_mark", null, this.getPackageName());
                iconImageView.setImageResource(imageResource);
            }

            //TURN OFF DND When checked out
            if (checkinIntent.getStringExtra("success").equals("OUT")) {
                changeInterruptionFiler(NotificationManager.INTERRUPTION_FILTER_ALL);
                //change image to exit icon
                int imageResource = getResources().getIdentifier("@drawable/goodbye_icon", null, this.getPackageName());
                iconImageView.setImageResource(imageResource);
            }
        }

        final Button trackOnceButton = findViewById(R.id.track_once_button);
        trackOnceButton.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                trackOnceButton.setEnabled(false);

                Radar.trackOnce(new RadarCallback() {
                    @Override
                    public void onComplete(@NonNull Radar.RadarStatus status, Location location, RadarEvent[] events, RadarUser user) {
                        trackOnceButton.setEnabled(true);

                        String statusString = Utils.stringForStatus(status);
                        Snackbar.make(trackOnceButton, statusString, Snackbar.LENGTH_SHORT).show();

                        if (status == Radar.RadarStatus.SUCCESS) {
                            //print coordinates
                            System.out.println("LOOK HERE!!! LOC: " + location);
                            Log.i(TAG, statusString);

                            RadarGeofence[] geofences = user.getGeofences();
                            if (geofences != null) {
                                for (RadarGeofence geofence : geofences) {
                                    String geofenceString = geofence.getDescription();
                                    Log.i(TAG, geofenceString);
                                }
                            }

                            if (user.getPlace() != null) {
                                String placeString = user.getPlace().getName();
                                Log.i(TAG, placeString);
                            }

                            for (RadarEvent event : events) {
                                String eventString = Utils.stringForEvent(event);
                                Log.i(TAG, eventString);
                            }
                        } else {
                            Log.e(TAG, statusString);
                        }
                    }
                });
            }
        });

//        if (autoTrack) {
//            System.out.println("RUNNING!");
//            trackOnceButton.performClick();
//            try { Thread.sleep(30000); }
//            catch (InterruptedException ex) { android.util.Log.d("YourApplicationName", ex.toString()); }
//        }

        if (checkinIntent.getStringExtra("buttonString") != null) {
            trackOnceButton.setText(checkinIntent.getStringExtra("buttonString"));
        }

        final Switch trackingSwitch = findViewById(R.id.tracking_switch);
        trackingSwitch.setChecked(Radar.isTracking());
        trackingSwitch.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Radar.startTracking();
                    autoTrack = true;
//                    System.out.println("RUNNING!");
//                    trackOnceButton.performClick();
//                    try { Thread.sleep(30000); }
//                    catch (InterruptedException ex) { android.util.Log.d("YourApplicationName", ex.toString()); }
                } else {
                    Radar.stopTracking();
                    autoTrack = false;
                }
            }
        });
    }





    protected void changeInterruptionFiler(int interruptionFilter){
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){ // If api level minimum 23
            /*
                boolean isNotificationPolicyAccessGranted ()
                    Checks the ability to read/modify notification policy for the calling package.
                    Returns true if the calling package can read/modify notification policy.
                    Request policy access by sending the user to the activity that matches the
                    system intent action ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS.

                    Use ACTION_NOTIFICATION_POLICY_ACCESS_GRANTED_CHANGED to listen for
                    user grant or denial of this access.

                Returns
                    boolean

            */
            // If notification policy access granted for this package
            if(mNotificationManager.isNotificationPolicyAccessGranted()){
                /*
                    void setInterruptionFilter (int interruptionFilter)
                        Sets the current notification interruption filter.

                        The interruption filter defines which notifications are allowed to interrupt
                        the user (e.g. via sound & vibration) and is applied globally.

                        Only available if policy access is granted to this package.

                    Parameters
                        interruptionFilter : int
                        Value is INTERRUPTION_FILTER_NONE, INTERRUPTION_FILTER_PRIORITY,
                        INTERRUPTION_FILTER_ALARMS, INTERRUPTION_FILTER_ALL
                        or INTERRUPTION_FILTER_UNKNOWN.
                */

                // Set the interruption filter
                mNotificationManager.setInterruptionFilter(interruptionFilter);
            }else {
                /*
                    String ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS
                        Activity Action : Show Do Not Disturb access settings.
                        Users can grant and deny access to Do Not Disturb configuration from here.

                    Input : Nothing.
                    Output : Nothing.
                    Constant Value : "android.settings.NOTIFICATION_POLICY_ACCESS_SETTINGS"
                */
                // If notification policy access not granted for this package
                Intent intent = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
                startActivity(intent);
            }
        }
    }
}
