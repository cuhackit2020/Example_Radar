package io.radar.example;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.TextView;

import io.radar.sdk.Radar;
import io.radar.sdk.RadarReceiver;
import io.radar.sdk.model.RadarEvent;
import io.radar.sdk.model.RadarUser;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Date;

public class ExampleRadarReceiver extends RadarReceiver {

    private static final String TAG = "ExampleRadarReceiver";
    private static final int NOTIFICATION_ID = 1337;

    public static String getCurrentTimeStamp(){
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String currentDateTime = dateFormat.format(new Date()); // Find todays date
            return currentDateTime;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void onEventsReceived(@NonNull Context context, @NonNull RadarEvent[] events, @NonNull RadarUser user) {
        if (events.length > 0) {
            for (RadarEvent event : events) {
                String eventString = Utils.stringForEvent(event);
                notify(context, "Event", eventString);

                //What to do when user enters a geofence
                if (event.getType() == RadarEvent.RadarEventType.USER_ENTERED_GEOFENCE) {
                    Intent checkinIntent = new Intent(context, MainActivity.class);
                    checkinIntent.putExtra("key", "You successfully checked in!"); //Optional parameter
                    checkinIntent.putExtra("time", getCurrentTimeStamp());
                    checkinIntent.putExtra("str", "Checked in");
                    checkinIntent.putExtra("buttonString", "CHECK OUT");
                    checkinIntent.putExtra("success", "IN");
                    context.startActivity(checkinIntent);

                    //what to do when user leaves a geofence
                } else if (event.getType() == RadarEvent.RadarEventType.USER_EXITED_GEOFENCE) {
                    Intent checkoutIntent = new Intent(context, MainActivity.class);
                    checkoutIntent.putExtra("key", "You successfully checked out!"); //Optional parameter
                    checkoutIntent.putExtra("time", getCurrentTimeStamp());
                    checkoutIntent.putExtra("str", "Checked out");
                    checkoutIntent.putExtra("buttonString", "CHECK IN");
                    checkoutIntent.putExtra("success", "OUT");
                    context.startActivity(checkoutIntent);

                }
            }
        }
        else {
            //neither enter nor leave
            Intent failureIntent = new Intent(context, MainActivity.class);
            failureIntent.putExtra("key", "Checkin/Checkout failed."); //Optional parameter
            context.startActivity(failureIntent);
        }
    }

    @Override
    public void onLocationUpdated(Context context, Location location, RadarUser user) {
        String state = "Moved to";

        if (user.getStopped()) {
            state = "Stopped at";
//            checkinTextView.setText("CHECKED OUT");
//            Intent checkoutIntent = new Intent(context, MainActivity.class);
//            checkoutIntent.putExtra("key", "CHECKED OUT"); //Optional parameter
//            context.startActivity(checkoutIntent);
        }
        else {
//            checkinTextView.setText("CHECKED IN");
//            Intent checkinIntent = new Intent(context, MainActivity.class);
//            checkinIntent.putExtra("key", "CHECKED IN"); //Optional parameter
//            context.startActivity(checkinIntent);
        }
        String locationString = String.format(Locale.getDefault(), "%s location (%f, %f) with accuracy %d meters",
            state, location.getLatitude(), location.getLongitude(), (int)location.getAccuracy());
        notify(context, "Location", locationString);
    }

    @Override
    public void onError(@NonNull Context context, @NonNull Radar.RadarStatus status) {
        String statusString = Utils.stringForStatus(status);
        notify(context, "Error", statusString);
    }

    private void notify(Context context, String title, String text) {
        Intent intent = new Intent(context, ExampleRadarReceiver.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationManager notificationManager = (NotificationManager)context.getSystemService(android.content.Context.NOTIFICATION_SERVICE);
        String channelName = "RadarExample";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel
                channel = new NotificationChannel(channelName, channelName,  NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
        }

        Notification notification = new NotificationCompat.Builder(context, channelName)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(pending)
                .setSmallIcon(io.radar.sdk.R.drawable.notification)
                .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                .build();


        notificationManager.notify(TAG, NOTIFICATION_ID, notification);
    }

}
